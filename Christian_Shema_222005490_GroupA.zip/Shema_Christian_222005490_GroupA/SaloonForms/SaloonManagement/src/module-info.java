/**
 * 
 */
/**
 * 
 */
module SaloonManagement {
}