package SaloonForm;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentListener;
import java.util.EventObject;

public class Appointments implements ActionListener {

	
		
		//frame
		
		JFrame frame;
		
		JLabel id_lb=new JLabel("ID");
		JLabel customerId_lb=new JLabel("CUSTOMER ID");
		JLabel appointmentDate_lb=new JLabel("APPOINTMENT DATE");
		JLabel StartTime_lb=new JLabel("START TIME");
		JLabel  EndTime_lb=new JLabel("END TIME");
		JLabel Serviceid_lb=new JLabel("SERVIVE ID");

		
		// TEXT FIELD
		
		JTextField id_txf=new JTextField();
		JTextField customerId_txf=new JTextField();
		static JTextField appointmentDate_txf=new JTextField();
		JTextField StartTime_txf=new JTextField();
		JTextField  EndTime_txf=new JTextField();
		JTextField  Serviceid_txf=new JTextField();
		
		//button
		
		JButton insert_btn=new JButton("Insert");
		
		JButton Read_btn=new JButton("View");
		JButton update_tbtn=new JButton("Update");
		JButton delete_btn=new JButton("Delete");
		Dimension screensize=Toolkit.getDefaultToolkit().getScreenSize();
		int w=(int) screensize.getWidth();
		int h=(int) screensize.getHeight();
		public void StudentForm() {
			createForm();

		}
		private void createForm() {
			frame=new JFrame();
			frame.setTitle("APPOINTMENTS FORM");
			frame.setBounds(100,100, 800, 600);
			frame.getContentPane().setLayout(null);
			frame.getContentPane().setBackground(Color.magenta);
			frame.setVisible(true);
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.setResizable(true);
			setLocationandSize();
		}
	private void setLocationandSize() {
			
		id_lb.setBounds(10, 10, 100, 30);
		customerId_lb.setBounds(10, 50, 100, 30);
		appointmentDate_lb.setBounds(10, 90, 100, 30);
		StartTime_lb.setBounds(10, 130, 100, 30);
		 EndTime_lb.setBounds(10, 170, 100, 30);
		 Serviceid_lb.setBounds(10, 210, 100, 30);
		id_txf.setBounds(160, 10, 130, 30);
		customerId_txf.setBounds(160, 50, 130, 30);
		appointmentDate_txf.setBounds(160, 90, 130, 30);
		StartTime_txf.setBounds(160, 130, 130, 30);
		EndTime_txf.setBounds(160, 170, 130, 30);
		Serviceid_txf.setBounds(160, 210, 130, 30);	
		
		//button CRUD
		
		
		insert_btn.setBounds(10,250, 85, 30);
		Read_btn.setBounds(100,250, 85, 30);
		update_tbtn.setBounds(190,250, 85, 30);
		delete_btn.setBounds(280,250, 85, 30);
		setFontforall();
		addcomponentforFrame();
		
		
		
	}
	

private void setFontforall() {
		
	
	Font font = new Font("Georgia", Font.BOLD, 18);

	id_lb.setFont(font);
	customerId_lb.setFont(font);
	appointmentDate_lb.setFont(font);
	StartTime_lb.setFont(font);
	EndTime_lb.setFont(font);
	Serviceid_lb.setFont(font);

	id_txf.setFont(font);
	customerId_txf.setFont(font);
	appointmentDate_txf.setFont(font);
	StartTime_txf.setFont(font);
	EndTime_txf.setFont(font);
	Serviceid_lb.setFont(font);
	
	Font fonti = new Font("Courier New", Font.ROMAN_BASELINE, 18);

	insert_btn.setFont(fonti);
	Read_btn.setFont(fonti);
	update_tbtn.setFont(fonti);
	delete_btn.setFont(fonti);
	
	}

private void addcomponentforFrame() {
		
	frame.add(id_lb);
	frame.add(customerId_lb);
	frame.add(appointmentDate_lb);
	frame.add(StartTime_lb);
	frame.add(EndTime_lb);
	frame.add(Serviceid_lb);
	frame.add(id_txf);
	frame.add(customerId_txf);
	frame.add(appointmentDate_txf);
	frame.add(StartTime_txf);
	frame.add(EndTime_txf);
	frame.add(Serviceid_txf);	
	
	
	//Buttons CRUD
			frame.add(insert_btn);
			frame.add(Read_btn);
			frame.add(update_tbtn);
			frame.add(delete_btn);
			ActionEvent();
	
	
	}
private void ActionEvent() {
	
	insert_btn.addComponentListener((ComponentListener) this);
	Read_btn.addComponentListener((ComponentListener) this);
	update_tbtn.addComponentListener((ComponentListener) this);
	delete_btn.addComponentListener((ComponentListener) this);
}

public static void main(String[] args, EventObject e) {
	Appointments app =new Appointments();
	
	try {
		if(e.getSource()==insert_btn) {
			app .setid(id_txf.getText());
			app .setcustomerId(customerId_txf.getText());
			app .setappointmentDate(appointmentDate_txf.getText());
			app .setStartTime(StartTime_txf.getText());
			
		
			//app.insertData(app.getid(), app.getcustomerid(), st.getEmail(), st.getTelephone(), st.getGender());
			//st.insertData();
		}else if (e.getSource()==insert_btn) {
			int id=Integer.parseInt(id_txf.getText());
			st.readwithID(id);
			id_txf.setText(String.valueOf(app.getid()));
			try {
				try {
					appointmentDate_txf.setText(app.getappointmentDate());
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			StartTime_txf.setText(app.getStartTime());
			EndTime_txf.setText(app.getEndTime());
			Serviceid_txf.setText(app.getServiceid());
			
			
		}else if (e.getSource()==update_tbtn) {
			int id=Integer.parseInt(id_txf.getText());
			//st.readwithID(id);
			//id_txf.setText(String.valueOf(st.getId()));
			//fname_txf.setText(st.getFname());
			//lname_txf.setText(st.getLname());
			//email_txf.setText(st.getEmail());
			//telephone_txf.setText(st.getTelephone());
			//st.setGender(st.getGender());
			app.setid(id_txf.getText());
			app.setLname(customerId_txf.getText());
			app.setEmail(email_txf.getText());
			app.setTelephone(telephone_txf.getText());
			app.setGender((String)genderBox.getSelectedItem());
			st.update(id);
		}else {
			int id=Integer.parseInt(id_txf.getText());
			st.delete(id);
		}
	} catch (NumberFormatException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
		
	}
private Object getid() {
	// TODO Auto-generated method stub
	return null;
}
@Override
public void actionPerformed(ActionEvent e) {
	// TODO Auto-generated method stub
	
}}
