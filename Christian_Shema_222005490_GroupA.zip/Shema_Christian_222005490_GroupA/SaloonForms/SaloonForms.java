package SaloonForm;

import java.awt.Color;
import java.awt.font.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import com.mysql.cj.jdbc.ClientPreparedStatement;

import javax.swing.JButton;
public class SaloonForms<PreparedStatement> implements ActionListener{
			JFrame frame;
			JLabel id_lb=new JLabel("ID");
			JLabel fname_lb=new JLabel("First name");
			JLabel lname_lb=new JLabel("Last Name");
			JLabel Phone_lb=new JLabel("Phone");
			JLabel email_lb=new JLabel("Email");
			JLabel address_lb=new JLabel("Address");
			
			JTextField id_txf=new JTextField();
			JTextField fname_txf=new JTextField();
			JTextField lname_txf=new JTextField();
			JTextField phone_txf=new JTextField();
			JTextField email_txf=new JTextField();
			JTextField address_txf=new JTextField();
			
			
			
			//Buttons CRUD
			JButton insert_btn=new JButton("Insert");
			JButton Read_btn=new JButton("View");
			JButton update_tbtn=new JButton("Update");
			JButton delete_btn=new JButton("Delete");
			Dimension screensize=Toolkit.getDefaultToolkit().getScreenSize();
			int w=(int) screensize.getWidth();
			int h=(int) screensize.getHeight();
			public SaloonForms() {
				createForm();
			
			}
			public void insert() {
				try {
				Class.forName(com.mysql.cj.jdbc.Driver);
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost/saloon_management_system","root","");
				String sql="INSERT INTO Customers VALUES(?,?,?,?,?,?)";
				PreparedStatement stm=con.preparedStatement();
				 stm.setInt(1,Integer.parseInt(id_txf.getText()));
				} catch (Exception e) {
					// TODO: handle exception
				}
			}
			
				private void createForm() {
					frame=new JFrame();
					frame.setTitle("CUSTOMERS FORM");
					frame.setBounds(0, 0, w/2, h/2);
					frame.getContentPane().setLayout(null);
					frame.getContentPane().setBackground(Color.GRAY);
					frame.setVisible(true);
					frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					frame.setResizable(true);
					setLocationandSize();
				}
				private void setLocationandSize() {
					id_lb.setBounds(10, 10, 100, 30);
					fname_lb.setBounds(10, 50, 100, 30);
					lname_lb.setBounds(10, 90, 100, 30);
					Phone_lb.setBounds(10, 130, 100, 30);
					email_lb.setBounds(10, 170, 100, 30);
					address_lb.setBounds(10, 210, 100, 30);
				
					id_txf.setBounds(160, 10, 130, 30);
					fname_txf.setBounds(160, 50, 130, 30);
					lname_txf.setBounds(160, 90, 130, 30);
					phone_txf.setBounds(160, 130, 130, 30);
					email_txf.setBounds(160, 170, 130, 30);
					address_txf.setBounds(160, 210, 130, 30);
					
					insert_btn.setBounds(10,250, 85, 30);
					//insert_btn.addActionListener(new);
					Read_btn.setBounds(100,250, 85, 30);
					update_tbtn.setBounds(190,250, 85, 30);
					delete_btn.setBounds(280,250, 85, 30);
				   
				addcomponentforFrame();

			}
			
	
			private void addcomponentforFrame() {
				frame.add(id_lb);
				frame.add(fname_lb);
				frame.add(lname_lb);
				frame.add(email_lb);
				frame.add(Phone_lb);
				frame.add(address_lb);
				
				frame.add(id_txf);
				frame.add(fname_txf);
				frame.add(lname_txf);
				frame.add(email_txf);
				frame.add(phone_txf);
				frame.add(address_lb);
				
				//Buttons CRUD
				frame.add(insert_btn);
				frame.add(Read_btn);
				frame.add(update_tbtn);
				frame.add(delete_btn);
				ActionEvent();
				
			}

					
			private void ActionEvent() {
				insert_btn.addActionListener(this);
				Read_btn.addActionListener(this);
				update_tbtn.addActionListener(this);
				delete_btn.addActionListener(this);
				
			}
			public static void main(String[]arg) {
				SaloonForms sln =new SaloonForms();
			}

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
			}

			}

